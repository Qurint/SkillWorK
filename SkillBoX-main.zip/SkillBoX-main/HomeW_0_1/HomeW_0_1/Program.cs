﻿using System;
using static System.Console;
namespace HomeW_0_1
{
    internal class Program
    {
        static void Main()
        {
            WriteLine("Hello World !");

            //Work 2

            Write("Hello");
            Write(" World");
            Write(" !!!");

            ReadLine();
        }
    }
}
